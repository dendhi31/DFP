Copy the contents of this directory to the location of your PHP source files
that is on your PHP include path.

